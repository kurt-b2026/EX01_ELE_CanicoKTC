/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01_ele_canicoktc;

/**
 *
 * @author Kurt Travis Canico
 */
public class EX01_ELE_CanicoKTC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int size1 = 30100, size2 = 793, size3 = 5060;
        String game1 = "Kerbal Space Program", game2 = "Democracy4", game3 = "SCP Secret Laboratory";
        double time1 = 2.56, time2 = .167, time3 = 3.12;
        
        System.out.println("Game 1 \nName: " + game1 + "\nSize: " + size1 + " MB\nTime since first play in years: " + time1);
        System.out.println("\nGame 2 \nName: " + game2 + "\nSize: " + size2 + " MB\nTime since first play in years: " + time2);
        System.out.println("\nGame 3 \nName: " + game3 + "\nSize: " + size3 + " MB\nTime since first play in years: " + time3 + "\n\nTotal Size: ");
        System.out.println(size1+size2+size3 + " MB");
        System.out.println("Kerbal Space Program has a bigger file size than Democracy4: ");
        System.out.println(size1>size2);
        System.out.println("I've had Democracy4 for longer than SCP Secret Laboratory: ");
        System.out.println(time2>time3);
    }
    
}
